export interface User {
  id: string;
  email: string;
  password: string;
  role: 'student' | 'admin';
  name: string;
}

// Mock user database for demonstration
export const mockUsers: User[] = [
  {
    id: '1',
    email: 'admin@university.edu',
    password: 'admin123',
    role: 'admin',
    name: 'Admin User',
  },
  {
    id: '2',
    email: 'student@university.edu',
    password: 'student123',
    role: 'student',
    name: 'John Student',
  },
  {
    id: '3',
    email: 'jane.doe@university.edu',
    password: 'password123',
    role: 'student',
    name: 'Jane Doe',
  },
  {
    id: '4',
    email: 'admin2@university.edu',
    password: 'admin456',
    role: 'admin',
    name: 'Sarah Admin',
  },
];

export const authenticateUser = (email: string, password: string): User | null => {
  const user = mockUsers.find(
    (u) => u.email.toLowerCase() === email.toLowerCase() && u.password === password
  );
  return user || null;
};

export const getUserByEmail = (email: string): User | null => {
  return mockUsers.find((u) => u.email.toLowerCase() === email.toLowerCase()) || null;
};
